var product = [{
    "id": 0,
    "title": "",
    "price": "",
    "description": "",
    "brand": "",
    "image": "https://upload.wikimedia.org/wikipedia/commons/thumb/6/65/No-Image-Placeholder.svg/1665px-No-Image-Placeholder.svg.png"
}, {
    "id": 1,
    "title": "Samsung Galaxy S22",
    "price": 179999,
    "description": "Samsung Galaxy S22 price in Pakistan is Rs. 179,999. Official dealers and warranty providers regulate the retail price of Samsung mobile products in official warranty.",
    "brand": "Samsung ",
    "image": "https://www.whatmobile.com.pk/admin/images/Samsung/SamsungGalaxyS22-b.jpg"
}, {
    "id": 2,
    "title": "Vivo X80",
    "price": 159999,
    "description": "Vivo X80 price in Pakistan is Rs. 159,999. Official dealers and warranty providers regulate the retail price of Vivo mobile products in official warranty.",
    "brand": "Vivo",
    "image": "https://www.whatmobile.com.pk/admin/images/Vivo/VivoX80-b.jpg"
}, {
    "id": 3,
    "title": "Oppo F21 Pro 5G",
    "price": 69999,
    "description": "Oppo F21 Pro 5G price in Pakistan is Rs. 69,999. Official dealers and warranty providers regulate the retail price of Oppo mobile products in official warranty.",
    "brand": "Oppo",
    "image": "https://www.whatmobile.com.pk/admin/images/Oppo/OppoF21Pro5G-b.jpg"
}, {
    "id": 4,
    "title": "Infinix Note 12",
    "price": 36999,
    "description": "Infinix Note 12 price in Pakistan is Rs. 36,999. Official dealers and warranty providers regulate the retail price of Infinix mobile products in official warranty.",
    "brand": "Infinix",
    "image": "https://www.whatmobile.com.pk/admin/images/Infinix/InfinixNote12-b.jpg"
}, {
    "id": 5,
    "title": "Samsung Galaxy A13",
    "price": 35499,
    "description": "Samsung Galaxy A13 price in Pakistan is Rs. 35,499. Official dealers and warranty providers regulate the retail price of Samsung mobile products in official warranty.",
    "brand": "Samsung",
    "image": "https://www.whatmobile.com.pk/admin/images/Samsung/SamsungGalaxyA13-b.jpg"
}, {
    "id": 6,
    "title": "Xiaomi 12",
    "price": 179999,
    "description": "Xiaomi 12 price in Pakistan is Rs. 179,999. Official dealers and warranty providers regulate the retail price of Xiaomi mobile products in official warranty.",
    "brand": "Xiaomi",
    "image": "https://www.whatmobile.com.pk/admin/images/Xiaomi/Xiaomi12-b.jpg"
}, {
    "id": 7,
    "title": "Huawei Nova 9",
    "price": 107999,
    "description": "Huawei Nova 9 price in Pakistan is Rs. 107,999. Official dealers and warranty providers regulate the retail price of Huawei mobile products in official warranty.",
    "brand": "Huawei",
    "image": "https://www.whatmobile.com.pk/admin/images/Huawei/HuaweiNova9-b.jpg"
}, {
    "id": 8,
    "title": "Realme C35",
    "price": 32999,
    "description": "Realme C35 price in Pakistan is Rs. 32,999. Official dealers and warranty providers regulate the retail price of Realme mobile products in official warranty.",
    "brand": "Realme",
    "image": "https://www.whatmobile.com.pk/admin/images/Realme/RealmeC35-b.jpg"
}, {
    "id": 9,
    "title": "Tecno Spark 8C 3GB",
    "price": 20499,
    "description": "Tecno Spark 8C 3GB price in Pakistan is Rs. 20,499. Official dealers and warranty providers regulate the retail price of Tecno mobile products in official warranty.",
    "brand": "Tecno",
    "image": "https://www.whatmobile.com.pk/admin/images/Tecno/TecnoSpark8C3GB-b.jpg"
}, {
    "id": 10,
    "title": "itel Vision 3",
    "price": 16299,
    "description": "itel Vision 3 price in Pakistan is Rs. 16,299. Official dealers and warranty providers regulate the retail price of itel mobile products in official warranty.",
    "brand": "Itel",
    "image": "https://www.whatmobile.com.pk/admin/images/itel/itelVision3-b.jpg"
}]